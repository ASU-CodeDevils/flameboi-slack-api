# TODO: implement this

from urllib.parse import urlparse
import json


class SlashCommand:

    def __init__(self):
        pass
