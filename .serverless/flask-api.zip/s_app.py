import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='stucamp',
    application_name='flameboi-dev',
    app_uid='z3nBbGj6G1sgzsjGNw',
    org_uid='kVnGW2trmwkJC20R5R',
    deployment_uid='dc9cf475-ddcb-4e9d-b7fd-8cea2ba44014',
    service_name='flask-api',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='3.6.15',
    disable_frameworks_instrumentation=False
)
handler_wrapper_kwargs = {'function_name': 'flask-api-dev-app', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
